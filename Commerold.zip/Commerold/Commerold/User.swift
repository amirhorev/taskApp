//
//  User.swift
//  Commerold
//
//  Created by hackeru on 11/04/2020.
//  Copyright © 2020 hackeru. All rights reserved.
//

import Foundation

// saving object work for both classes and structs. we have an example of each type below

// we conform to the Codable protocol. the Codable protocol is a combination of the Encodable and Decodable protocols
// they allow us to convert then into data and revert from data using an encoder and decoder respectively
// in our case, we will be using the JSONEncoder and JSONDecoder

struct User: Codable, CustomStringConvertible
{
    var userID: String
    var userEmail: String
    var userPassword: String
    var userFirstName: String
    var userLastName: String
    
    
    init(_ userID: String, _ userEmail: String, _ userPassword: String, _ userFirstName: String, _ userLastName: String)
    {
        self.userID = userID
        self.userEmail = userEmail
        self.userPassword = userPassword
        self.userFirstName = userFirstName
        self.userLastName = userLastName
    }
    
    var description: String
    {
        return "userID: \(userID), userFirstName: \(userFirstName), userLastName: \(userLastName)"
    }
}
