//
//  NSDictionary+getters.swift
//  Commerold
//
//  Created by hackeru on 11/04/2020.
//  Copyright © 2020 hackeru. All rights reserved.
//

import Foundation

extension NSDictionary
{
    func getString(_ key: String) -> String
    {
        return (self[key] ?? "") as! String
    }
}
