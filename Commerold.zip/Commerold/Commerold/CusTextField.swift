//
//  CusTextField.swift
//  Commerold
//
//  Created by hackeru on 25/03/2020.
//  Copyright © 2020 hackeru. All rights reserved.
//

import UIKit

@IBDesignable
class CusTextField: UITextField
{
    var defaultBorderColor:CGColor = UIColor.gray.cgColor
    
    
    override init(frame: CGRect) {
        super.init(frame: frame)
        setupView()
    }
    
    //initWithCode to init view from xib or storyboard
    required init?(coder aDecoder: NSCoder) {
        super.init(coder: aDecoder)
        setupView()
    }
    
    //common func to init our view
    private func setupView()
    {}
    
    
    func colorTextField(action: String?)
    {
        var borderColor:CGColor
        var borderWidth:CGFloat
        
        
        if((action ?? "").isEmpty)
        {
            borderColor = defaultBorderColor
            borderWidth = 0
        }
            
        else
        {
            switch action
            {
            case "error":
                borderColor = UIColor.red.cgColor
                borderWidth = 1.0
            default:
                borderColor = defaultBorderColor
                borderWidth = 0
            }
        }
        
        self.layer.borderWidth = borderWidth
        self.layer.borderColor = borderColor
    }
}
