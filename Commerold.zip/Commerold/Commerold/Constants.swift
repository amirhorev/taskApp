//
//  Constants.swift
//  Commerold
//
//  Created by hackeru on 30/03/2020.
//  Copyright © 2020 hackeru. All rights reserved.
//

import Foundation

struct Constants
{
    static let SERVER_ROOT:String = "http://192.168.0.106/"
    
    static let SERVER_RESP_SUCCESS:String = "success";
    static let SERVER_RESP_ERROR:String = "error";
    static let SERVER_RESP_REQUEST_ERROR:String = "request_error";
}
