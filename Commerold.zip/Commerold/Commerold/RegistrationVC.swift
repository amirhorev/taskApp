//
//  RegistrationVC.swift
//  Commerold
//
//  Created by hackeru on 21/03/2020.
//  Copyright © 2020 hackeru. All rights reserved.
//

import UIKit


class RegistrationVC: UIViewController
{
    var loginVCInstance: LoginVC? = nil
    

    @IBOutlet weak var tfEmail: CusTextField!
    @IBOutlet weak var tfPassword: CusTextField!
    @IBOutlet weak var tfPasswordAgain: CusTextField!
    @IBOutlet weak var tfFirstName: CusTextField!
    @IBOutlet weak var tfLastName: CusTextField!
    
    
    override func viewDidLoad()
    {
        super.viewDidLoad()
    }
    
    
    @IBAction func btnRegisterTapped(_ sender: Any)
    {
        registerUser()
    }
    
    fileprivate func registerUser()
    {
        // get the input values
        
        guard let valUserEmail = tfEmail.text else
        {
            tfEmail.colorTextField(action: "error")
            return
        }
        
        guard let valUserPassword = tfPassword.text else
        {
            tfPassword.colorTextField(action: "error")
            return
        }
        
        guard let valUserPasswordAgain = tfPasswordAgain.text else
        {
            tfPasswordAgain.colorTextField(action: "error")
            return
        }
        
        guard let valUserFirstName = tfFirstName.text else
        {
            tfFirstName.colorTextField(action: "error")
            return
        }
        
        guard let valUserLastName = tfLastName.text else
        {
            tfLastName.colorTextField(action: "error")
            return
        }
        
        
        
        // validate the input values
        
        let validation = Validation()
        var validationRegFlag:Bool = true
        
        
        let isValidateEmail = validation.validateEmail(email: valUserEmail)
        if (isValidateEmail == false)
        {
            validationRegFlag = false
            tfEmail.colorTextField(action: "error")
        }
        
        else
        {
            tfEmail.colorTextField(action: "none")
        }
        
        
        let isValidatePassword = validation.validatePassword(password: valUserPassword)
        if (isValidatePassword == false)
        {
            validationRegFlag = false
            tfPassword.colorTextField(action: "error")
        }
        
        else
        {
            tfPassword.colorTextField(action: "none")
        }
        
        
        let isValidatePasswordAgain = valUserPassword == valUserPasswordAgain
        if (isValidatePasswordAgain == false)
        {
            validationRegFlag = false
            tfPasswordAgain.colorTextField(action: "error")
        }
        
        else
        {
            tfPasswordAgain.colorTextField(action: "none")
        }
        
        
        let isValidateFirstName = validation.validateName(name: valUserFirstName)
        if (isValidateFirstName == false)
        {
            validationRegFlag = false
            tfFirstName.colorTextField(action: "error")
        }
        
        else
        {
            tfFirstName.colorTextField(action: "none")
        }
        
        
        let isValidateLastName = validation.validateName(name: valUserLastName)
        if (isValidateLastName == false)
        {
            validationRegFlag = false
            tfLastName.colorTextField(action: "error")
        }
        
        else
        {
            tfLastName.colorTextField(action: "none")
        }
        
        
        if(validationRegFlag)
        {
            let http = Http(urlStringEndpoint: "pages/login/register-user.php")
            
            http.addParams([
                "UserEmail": valUserEmail,
                "UserPassword": valUserPassword,
                "UserPasswordAgain": valUserPasswordAgain,
                "UserFirstName": valUserFirstName,
                "UserLastName": valUserLastName
                ])
            
            
            http.requestPost() { statusCode, resultDic in
                

                switch(statusCode)
                {
                case 200,
                     201:
                    
                    let executionStatus = (resultDic["executionStatus"] ?? "") as! String
                    
                    switch(executionStatus)
                    {
                        
                    case Constants.SERVER_RESP_SUCCESS:
                        
                        if let loginVCInstance = self.loginVCInstance
                        {
                            // store the success message in the next screen
                            loginVCInstance.storedData = "registrationCompleted"
                        }

                        
                        // move back to the root view (Login)
                        self.navigationController?.popViewController(animated: true)
                        
                        
                    case Constants.SERVER_RESP_REQUEST_ERROR,
                         Constants.SERVER_RESP_ERROR:  self.showToast("An error occurred")
                        
                    case "error_userEmail":  self.tfEmail.colorTextField(action: "error")
                        
                    case "error_userPassword":  self.tfPassword.colorTextField(action: "error")
                        
                    case "error_passwordAgain":  self.tfPasswordAgain.colorTextField(action: "error")
                        
                    case "error_userFirstName":  self.tfFirstName.colorTextField(action: "error")
                        
                    case "error_userLastName":  self.tfLastName.colorTextField(action: "error")
                        
                    default:  self.showToast("An error occurred")
                    }
                    
                default:
                    
                    self.showToast("An error occurred")
                }
            }
        }
    }
}
