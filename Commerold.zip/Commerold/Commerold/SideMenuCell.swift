//
//  SideMenuCell.swift
//  Commerold
//
//  Created by hackeru on 13/04/2020.
//  Copyright © 2020 hackeru. All rights reserved.
//

import UIKit

class SideMenuCell: UITableViewCell
{
    @IBOutlet weak var lblButton: UILabel!
}
