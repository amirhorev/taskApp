//
//  TaskCell.swift
//  Commerold
//
//  Created by hackeru on 09/05/2020.
//  Copyright © 2020 hackeru. All rights reserved.
//

import UIKit

class TaskCell: UITableViewCell
{
    @IBOutlet weak var labelName: UILabel!
    @IBOutlet weak var labelHour: UILabel!
    @IBOutlet weak var imgState: UIImageView!
}
