//
//  ViewController.swift
//  Commerold
//
//  Created by hackeru on 18/03/2020.
//  Copyright © 2020 hackeru. All rights reserved.
//

import UIKit
import SQLite


class MainVC: CusViewController
{
    @IBOutlet weak var tvTasks: UITableView!
    
    // UITableViewDataSource has functions that describe the data of the tableview - the amount and how they look
    // UITableViewDelegate has functions that react to events such as selecting or swiping a row
    
    
    // a struct to describe a simple Person object
    
    struct  Task
    {
        var id: Int
        var name: String
        var hour: String
        var state: Bool
    }
    
    // the data source of the tablview
    var tasks: [Task]?
    {
        get
        {
            return try? getAllTasks()
        }
        
    }
    
    
    let databaseFileName = "tasks"
    
    let taskTable = Table("tasks")
    
    let fieldId = Expression<Int>("id")
    let fieldName = Expression<String>("name")
    let fieldHour = Expression<String>("hour")
    let fieldState = Expression<Bool>("status")
    
    
    var database: Connection?
    
    
    
    override func viewDidLoad()
    {
        super.viewDidLoad()
        
        // setting the class that has the datasource and delegate functions to this class
        tvTasks.dataSource = self
        tvTasks.delegate = self
        
        
        do
        {
            try getDatabaseFile()
            try createTable()
        }
            
        catch
        {
            print("got error: \(error)")
        }
    }
    
    
    @IBAction func btnAddTapped(_ sender: UIBarButtonItem)
    {
        // open an alert to insert a task into the sqlite table
        let alert = UIAlertController(title: "New Task", message: nil, preferredStyle: .alert)
        
        alert.addTextField { txt in
            txt.placeholder = "name"
            txt.textAlignment = .center
        }
        
        alert.addTextField { txt in
            txt.placeholder = "hour"
            txt.textAlignment = .center
        }
        
        alert.addAction(UIAlertAction(title: "close", style: .cancel, handler: nil))
        
        alert.addAction(UIAlertAction(title: "ok", style: .default, handler: { _ in
            
            // insert
            guard
                let name = alert.textFields?[0].text?.trimmingCharacters(in: .whitespacesAndNewlines),
                let hour = alert.textFields?[1].text?.trimmingCharacters(in: .whitespacesAndNewlines)
                else
            {
                    return
            }
            
            if name.isEmpty == true || hour.isEmpty == true {
                return
            }
            
            try? self.insertTask(name: name, hour: hour, state: false) // insert a new row into the table
            
            self.tvTasks.reloadData() // refresh the tableview
            
        }))
        
        present(alert, animated: true, completion: nil)
    }
}





// extension for all the SQLite functions
// note that we could also create a class in a separate file (for instance called SQLiteManager) and have all the functions there and call it from our ViewController
extension MainVC
{
    
    fileprivate func getDatabaseFile() throws
    {
        let documentDirectory  = try FileManager.default.url(for: .documentDirectory, in: .userDomainMask, appropriateFor: nil, create: false)
        let databaseUrl = documentDirectory.appendingPathComponent(databaseFileName).appendingPathExtension("sqlite3")
        
        database = try Connection(databaseUrl.path)
        
        print("database created at: \(databaseUrl.path)")
        
    }
    
    
    fileprivate func createTable() throws{
        
        let createQuery = taskTable.create(temporary: false, ifNotExists: true, withoutRowid: false) { tableBuilder in
            tableBuilder.column(self.fieldId, primaryKey: true)
            tableBuilder.column(self.fieldName)
            tableBuilder.column(self.fieldHour)
            tableBuilder.column(self.fieldState)
        }
        
        try database?.run(createQuery)
        
        print("table exists")
        
    }
    
    
    fileprivate func insertTask(name: String, hour: String, state: Bool) throws
    {
        let insertQuery = taskTable.insert(fieldName <- name, fieldHour <- hour, fieldState <- state)
        
        try database?.run(insertQuery)
        
        print("data inserted")
    }
    
    
    fileprivate func getAllTasks() throws -> [Task]
    {
        
        var tasks = [Task]()
        
        guard let results = try database?.prepare(taskTable) else
        {
            print("got no tasks")
            return tasks
        }
        
        for taskData in results
        {
            let task = Task(id: taskData[fieldId], name: taskData[fieldName], hour: taskData[fieldHour], state: taskData[fieldState])
            tasks.append(task)
        }
        
        print("got people")
        
        return tasks
    }
    
    
    fileprivate func getTask(id: Int) throws -> Task?{
        
        
        guard let results = try database?.prepare(taskTable.filter(fieldId == id)) else
        {
            print("didn't get a task")
            return nil
        }
        
        guard let taskData = Array(results).first else
        {
            print("didn't get a task")
            return nil
        }
        
        return  Task(id: taskData[fieldId], name: taskData[fieldName], hour: taskData[fieldHour], state: taskData[fieldState])
    }
    
    
    fileprivate func updateTask(id: Int, name: String, hour: String, state: Bool) throws
    {
        let updateQuery = taskTable.filter(fieldId == id).update(fieldName <- name, fieldHour <- hour, fieldState <- state)
        
        try database?.run(updateQuery)
        
        print("data updated")
    }
    
    
    fileprivate func deleteTask(id: Int) throws
    {
        let deleteQuery = taskTable.filter(fieldId == id).delete()
        
        try database?.run(deleteQuery)
        
        print("data deleted")
    }
}



// extension for the tableview datasource and delegate
// (we did not used the delegate here, it is need for the homework)
extension MainVC: UITableViewDataSource, UITableViewDelegate
{
    // datasource
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int
    {
        return tasks?.count ?? 0
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell
    {
        let cell = tableView.dequeueReusableCell(withIdentifier: "taskCell", for: indexPath) as! TaskCell
        
        let task = tasks?[indexPath.row]
        
        cell.labelName.text = task?.name ?? "no name"
        cell.labelHour.text = task?.hour ?? "no time"
        cell.imgState.image = UIImage(named: (task?.state ?? false) ? "done.png" : "notDone.png")
        
        // design (optional)
        cell.layer.cornerRadius = 10 // setting round corners
        cell.layer.borderWidth = 2  // adding a border
        
        cell.layer.borderColor  = UIColor.darkGray.cgColor // setting the border color
        
        return cell // return the cell now that we designed it
    }
    
    
    
    // delegate
    // note: none of the delegate functions are mandatory
    
    // function to set behavior for the click even on a row at a given indexPath
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath)
    {
        // get the Task object corresponding to the row in the indexPath
        guard let task = tasks?[indexPath.row] else
        {
            return
        }
        
        do
        {
            try updateTask(id: task.id, name: task.name, hour: task.hour, state: !task.state)
            
            tvTasks.reloadData()
        }
            
        catch
        {
            print("got error: \(error)")
        }
    }
    
    
    // functionn to add swipe actions
    func tableView(_ tableView: UITableView, editActionsForRowAt indexPath: IndexPath) -> [UITableViewRowAction]? {
        
        guard let task = tasks?[indexPath.row] else
        {
            return nil
        }
        
        
        // creating a delete action
        let deleteAction = UITableViewRowAction(style: .destructive, title: "delete") {  _, _ in
            
            do
            {
                try self.deleteTask(id: task.id)
                
                self.tvTasks.reloadData()
            }
                
            catch
            {
                print("got error: \(error)")
            }
        
            
            print("removed task \(task.name) at index \(indexPath.row)")
        }
        
        return [deleteAction] // return an array with all the actions (here we only have one but we could have more as well, for instance an update action)
        
    }
}
