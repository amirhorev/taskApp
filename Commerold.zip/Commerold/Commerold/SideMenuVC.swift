//
//  SideMenuVC.swift
//  Commerold
//
//  Created by hackeru on 13/04/2020.
//  Copyright © 2020 hackeru. All rights reserved.
//

import UIKit
import SideMenu

class SideMenuVC: DropDownTableViewController
{
    let buttonList = ["MainVC", "Logout"]
    
    let buttonListDic: [String: [String]] =
        [
            "MainVC": [],
            "Logout": []
        ]
    
    let sideMenuCellId = "sideMenuCell";
    
    
    @IBOutlet var tvMenu: UITableView!
    
    
    override func viewDidLoad()
    {
        super.viewDidLoad()
        
        // setting the class that has the datasource and delegate functions to this class
        //tvMenu.register(SideMenuCell.self, forCellReuseIdentifier: sideMenuCellId)
    }
    
    
    // datasource
    
    override func numberOfRows(in tableView: UITableView) -> Int
    {
        return buttonList.count
    }
    
    
    override func tableView(_ tableView: UITableView, numberOfSubrowsInRow row: Int) -> Int
    {
        if let buttonArray = buttonListDic[buttonList[row]]
        {
            return buttonArray.count
        }
        
        return 0
    }
    

    override func tableView(_ tableView: UITableView, cellForRow row: Int, indexPath: IndexPath) -> UITableViewCell
    {
        // getting the cell object that will we used at a given indexPath (note that index path holds a section and a row - in our case there is only one section so we only care about the row)
        let cellRow = tableView.dequeueReusableCell(withIdentifier: sideMenuCellId, for: indexPath) as! SideMenuCell // we specify the identifier that we gave the prototype cell in the storyboard and cast it to our cell class
        
        cellRow.lblButton.text = buttonList[row] // setting the text of the label for the button
       /*
        // if the row has subrows
        if let buttonArray = buttonListDic[buttonList[row]]
        {
            if(buttonArray.count > 0)
            {
                cellRow.accessoryView = UIImageView(image: UIImage(named: "arrow_down"))
            }
        }*/
        
        
        // design (optional)
        cellRow.layer.cornerRadius = 10 // setting round corners
        cellRow.layer.borderWidth = 2  // adding a border
        
        cellRow.layer.borderColor  = UIColor.darkGray.cgColor // setting the border color
        
        
        return cellRow // return the cell now that we designed it
    }
    
    /*
    override func tableView(_ tableView: UITableView, cellForSubrow subrow: Int, inRow row: Int, indexPath: IndexPath) -> UITableViewCell
    {
        let cellSubRow = tableView.dequeueReusableCell(withIdentifier: sideMenuCellId, for: indexPath) as! SideMenuCell
        
        
        if let buttonArray = buttonListDic[buttonList[row]]
        {
            cellSubRow.lblButton.text = buttonArray[subrow]
        }
        cellSubRow.layer.cornerRadius = 10 // setting round corners
        cellSubRow.layer.borderWidth = 2  // adding a border
        
        cellSubRow.layer.borderColor  = UIColor.darkGray.cgColor // setting the border color
        
        return cellSubRow
    }
    
    */
    
    
    // delegate
    
    override func tableView(_ tableView: UITableView, didSelectRow row: Int)
    {/*
        switch (self.nsk_selectedRow, row)
        {
        case (let sr?, _) where row == sr:
            tableView.cellForRow(at: row)?.accessoryView =  UIImageView(image: UIImage(named: "arrow_down"))
            tableView.deselect(row: row, animated: true)
            break
            
        case (let sr?, _) where row != sr:
            tableView.cellForRow(at: row)?.accessoryView = UIImageView(image: UIImage(named: "arrow_up"))
            tableView.cellForRow(at: sr)?.accessoryView = UIImageView(image: UIImage(named: "arrow_down"))
            break
            
        case (nil, _):
            tableView.cellForRow(at: row)?.accessoryView = UIImageView(image: UIImage(named: "arrow_up"))
            break
            
        default:
            break
        }*/
        
        
        // get the button corresponding to the row in the indexPath
        let button = buttonList[row]
        
        
        // make sure we have a reference of this Side menu's navigation controller
        if let cusSideMenuNC = self.navigationController as! CusSideMenuNC?
        {
            // make sure we have a reference of the sender view controller
            if let senderVC = cusSideMenuNC.senderVC
            {
                // check if the desired destination is not equal to the sender view controller
                if(String(describing: type(of: senderVC)) == button)
                {
                    dismiss(animated: true, completion: nil)
                    
                    
                    if(button == "Logout")
                    {
                        logout(cusSideMenuNC: cusSideMenuNC)
                    }
                    
                    else
                    {
                        senderVC.clickButton("MainNC")
                    }
                }
            }
        }
        
        
        super.tableView(tableView, didSelectRow: row)
    }
    
    
    private func logout(cusSideMenuNC: CusSideMenuNC)
    {
        // unlog the user
        UD.removeUserFromUD()
        
        // move to loginVC
        if let mainNC = cusSideMenuNC.mainNC
        {
            // set LoginVC as the root view of the main navigation controller
            let loginVC = self.storyboard?.instantiateViewController(withIdentifier: "LoginVC") as! LoginVC
        
            mainNC.viewControllers = [loginVC] as [UIViewController]
            
            // move back to the root view
            mainNC.popViewController(animated: true)
        }
    }
}
