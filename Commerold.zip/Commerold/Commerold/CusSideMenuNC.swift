//
//  CusSideMenuNC.swift
//  Commerold
//
//  Created by hackeru on 15/04/2020.
//  Copyright © 2020 hackeru. All rights reserved.
//

import Foundation
import SideMenu

class CusSideMenuNC: UISideMenuNavigationController
{
    var mainNC: UINavigationController?
    var senderVC: CusViewController?
}
