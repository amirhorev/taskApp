//
//  UIViewController+MBPToast.swift
//  Commerold
//
//  Created by hackeru on 30/03/2020.
//  Copyright © 2020 hackeru. All rights reserved.
//

import UIKit
import MBProgressHUD

extension UIViewController
{
    // we are using an instance of Property for holding stored properties in extension
    
    private static var _storedString = Property<String>()
    
    @IBInspectable var storedString : String
    {
        get
        {
            return UIViewController._storedString.get(self) ?? ""
        }
        
        set(newValue)
        {
            UIViewController._storedString.set(self, value: newValue)
        }
    }
    
    
    
    func showToast(_ text:String)
    {
        let hud = MBProgressHUD.showAdded(to: view, animated: true)
        
        hud.mode = MBProgressHUDMode.text
        hud.label.text = text
        hud.margin = 10
        hud.offset = CGPoint(x: 0, y: 350)
        hud.removeFromSuperViewOnHide = true
        hud.isUserInteractionEnabled = false
        hud.hide(animated: true, afterDelay: 10)
    }
}


// A class meant for holding stored properties in extension

public class Property<T: Any>
{
    private var property = [String:T]()
    
    func get(_ key: AnyObject) -> T?
    {
        return property["\(unsafeBitCast(key, to: Int.self))"] ?? nil
    }
    
    func set(_ key: AnyObject, value: T)
    {
        property["\(unsafeBitCast(key, to: Int.self))"] = value
    }
}
