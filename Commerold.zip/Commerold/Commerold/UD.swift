//
//  UD.swift
//  Commerold
//
//  Created by hackeru on 11/04/2020.
//  Copyright © 2020 hackeru. All rights reserved.
//

import Foundation

class UD
{
    // the keys of the data we store in this user defaults file
    public static let KEY_USER_ID: String = "UserId";
    public static let KEY_USER_EMAIL: String = "UserEmail";
    public static let KEY_USER_PASSWORD: String = "UserPassword";
    public static let KEY_USER_FIRST_NAME: String = "UserFirstName";
    public static let KEY_USER_LAST_NAME: String = "UserLastName";
    
    
    static func saveUserToUD(_ userID: String, _ userEmail: String, _ userPassword: String, _ userFirstName: String, _ userLastName: String)
    {
        let user = User(userID, userEmail, userPassword, userFirstName, userLastName) // creating an object to save
        
        let encoder = JSONEncoder() // creating an encoder
        
        if let userData = try? encoder.encode(user)
        {
            // converting the object we want to save into data
            UserDefaults.standard.set(userData, forKey: "currentUser") // saving the data in UserDefualts
            UserDefaults.standard.synchronize()
        }
    }
    
    static func removeUserFromUD()
    {
        UserDefaults.standard.removeObject(forKey: "currentUser")
        UserDefaults.standard.synchronize()
    }
    
    
    static func isUserLogged() -> Bool
    {
        return UserDefaults.standard.object(forKey: "currentUser") != nil
    }
}
