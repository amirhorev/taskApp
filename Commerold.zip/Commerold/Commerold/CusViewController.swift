//
//  CusViewController.swift
//  Commerold
//
//  Created by hackeru on 15/04/2020.
//  Copyright © 2020 hackeru. All rights reserved.
//

import UIKit

class CusViewController: UIViewController, SideMenuActions
{

    override func viewDidLoad()
    {
        super.viewDidLoad()
    }
    
    
    override func prepare(for segue: UIStoryboardSegue, sender: Any?)
    {
        if segue.identifier == "sideMenuSegue"
        {
            let cusSideMenuNC = segue.destination as! CusSideMenuNC
            cusSideMenuNC.mainNC = self.navigationController
            cusSideMenuNC.senderVC = self
        }
    }
    
    
    // Delegate Method
    func clickButton(_ button: String)
    {
        
    }

}


protocol SideMenuActions
{
    func clickButton(_ button: String)
}
