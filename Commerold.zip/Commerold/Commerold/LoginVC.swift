//
//  Login.swift
//  Commerold
//
//  Created by hackeru on 21/03/2020.
//  Copyright © 2020 hackeru. All rights reserved.
//

import UIKit

class LoginVC: UIViewController
{
    
    var storedData: String?
    
    
    @IBOutlet weak var tfLogEmail: CusTextField!
    @IBOutlet weak var tfLogPassword: CusTextField!
    
    
    override func viewDidLoad()
    {
        super.viewDidLoad()
    }
    
    
    override func viewDidAppear(_ animated: Bool)
    {        
        // check what is the previous ViewControllerif there is stored data
        if let storedData = storedData
        {
            switch storedData
            {
            case "registrationCompleted":
                
                self.showToast("Registration completed successfully!")
                
            default:
                return
            }
            
            self.storedData = ""
        }
    }

    
    @IBAction func btnLoginTpped(_ sender: Any)
    {
        // get the input values
        
        guard let valUserEmail = tfLogEmail.text else
        {
            tfLogEmail.colorTextField(action: "error")
            return
        }
        
        guard let valUserPassword = tfLogPassword.text else
        {
            tfLogPassword.colorTextField(action: "error")
            return
        }
        
        
        
        // validate the input values
        
        let validation = Validation()
        var validationRegFlag:Bool = true
        
        
        let isValidateEmail = validation.validateEmail(email: valUserEmail)
        if (isValidateEmail == false)
        {
            validationRegFlag = false
            tfLogEmail.colorTextField(action: "error")
        }
            
        else
        {
            tfLogEmail.colorTextField(action: "none")
        }
        
        
        let isValidatePassword = validation.validatePassword(password: valUserPassword)
        if (isValidatePassword == false)
        {
            validationRegFlag = false
            tfLogPassword.colorTextField(action: "error")
        }
            
        else
        {
            tfLogPassword.colorTextField(action: "none")
        }
        
        
        
        if(validationRegFlag)
        {
            let http = Http(urlStringEndpoint: "pages/login/log-user.php")
            
            http.addParams([
                "UserEmail": valUserEmail,
                "UserPassword": valUserPassword
                ])
            
            
            http.requestPost() { statusCode, resultDic in
                
                
                switch(statusCode)
                {
                case 200,
                     201:
                    
                    let executionStatus = resultDic.getString("executionStatus")
                    
                    switch(executionStatus)
                    {
                         // resultDic.getString(UD.KEY_USER_ID), valUserEmail, valUserPassword, resultDic.getString(UD.KEY_USER_FIRST_NAME), resultDic.getString(UD.KEY_USER_LAST_NAME)
                    case Constants.SERVER_RESP_SUCCESS:
                        
                        UD.saveUserToUD(resultDic.getString(UD.KEY_USER_ID), valUserEmail, valUserPassword, resultDic.getString(UD.KEY_USER_FIRST_NAME), resultDic.getString(UD.KEY_USER_LAST_NAME))
                        
                        // change the navigation controller to have MainVC is its root view
                        let mainVC = self.storyboard?.instantiateViewController(withIdentifier: "MainVC") as! MainVC
                        
                        self.navigationController?.viewControllers = [mainVC] as [UIViewController]
                        
                        // move back to the root view (Main)
                        self.navigationController?.popViewController(animated: true)
                        
                        
                    case Constants.SERVER_RESP_REQUEST_ERROR,
                         Constants.SERVER_RESP_ERROR:  self.showToast("An error occurred")
                    
                    default:  self.showToast("An error occurred")
                    }
                    
                default:
                    
                    self.showToast("An error occurred")
                }
            }
        }
    }
    
    
    override func prepare(for segue: UIStoryboardSegue, sender: Any?)
    {
        if segue.identifier == "LoginToRegistrationSegue"
        {
            let registrationVC: RegistrationVC = segue.destination as! RegistrationVC
            registrationVC.loginVCInstance = self
        }
    }
}
