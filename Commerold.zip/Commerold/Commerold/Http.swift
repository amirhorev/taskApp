//
//  APIRequest.swift
//  Commerold
//
//  Created by hackeru on 28/03/2020.
//  Copyright © 2020 hackeru. All rights reserved.
//

import Foundation
import Alamofire


// Optional Assignment, assigns if value exists
infix operator ?=: AssignmentPrecedence

func ?=<T>(lhs: inout T, rhs: T?)
{
    guard let value = rhs else { return }
    lhs = value
}



class Http
{
    let resourceURL: String
    var params: [String:Any] = [:]
    
    
    init(urlStringEndpoint: String)
    {
        self.resourceURL = Constants.SERVER_ROOT + urlStringEndpoint
    }
    
    
    func addParams(_ params: [String:Any])
    {
        self.params = params
    }
    
    
    func requestPost(completeonClosure: @escaping (Int, NSDictionary) -> ())
    {
        Alamofire.request(resourceURL, method: .post, parameters: params).responseJSON { response in
        
            
            let statusCode = response.response?.statusCode ?? 0
            
            let resultDic = (response.result.value ?? [:]) as! NSDictionary
            
            completeonClosure(statusCode, resultDic)
            
            
            // for developer
            print(resultDic)
        }
    }
}
